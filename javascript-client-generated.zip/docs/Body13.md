# CardsAgainsHumanityDrfApi.Body13

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**email** | **String** |  | 
