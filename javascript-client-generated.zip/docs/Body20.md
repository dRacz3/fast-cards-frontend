# CardsAgainsHumanityDrfApi.Body20

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**username** | **String** |  | [optional] 
**email** | **String** |  | [optional] 
**password** | **String** |  | 
