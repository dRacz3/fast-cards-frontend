# CardsAgainsHumanityDrfApi.Body25

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**key** | **String** |  | 
