# CardsAgainsHumanityDrfApi.InlineResponse2003

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**text** | **String** |  | 
**icon** | **String** |  | 
**deck** | **String** |  | 
**pick** | **Number** |  | 
