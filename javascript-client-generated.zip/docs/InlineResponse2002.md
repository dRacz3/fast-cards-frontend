# CardsAgainsHumanityDrfApi.InlineResponse2002

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**count** | **Number** |  | [optional] 
**next** | **String** |  | [optional] 
**previous** | **String** |  | [optional] 
**results** | **[Object]** |  | [optional] 
