# CardsAgainsHumanityDrfApi.Body24

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**key** | **String** |  | 
