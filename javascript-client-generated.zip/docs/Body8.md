# CardsAgainsHumanityDrfApi.Body8

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**text** | **String** |  | 
**icon** | **String** |  | 
**deck** | **String** |  | 
**pick** | **Number** |  | 
