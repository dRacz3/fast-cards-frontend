# CardsAgainsHumanityDrfApi.Body26

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**key** | **String** |  | 
