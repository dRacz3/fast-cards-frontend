# CardsAgainsHumanityDrfApi.Body9

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**text** | **String** |  | [optional] 
**icon** | **String** |  | [optional] 
**deck** | **String** |  | [optional] 
**pick** | **Number** |  | [optional] 
