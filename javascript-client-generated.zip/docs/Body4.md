# CardsAgainsHumanityDrfApi.Body4

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**text** | **String** |  | [optional] 
**icon** | **String** |  | [optional] 
**deck** | **String** |  | [optional] 
