# CardsAgainsHumanityDrfApi.Body22

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**username** | **String** |  | 
**email** | **String** |  | 
**password1** | **String** |  | 
**password2** | **String** |  | 
