# CardsAgainsHumanityDrfApi.Body17

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**newPassword1** | **String** |  | 
**newPassword2** | **String** |  | 
**uid** | **String** |  | 
**token** | **String** |  | 
