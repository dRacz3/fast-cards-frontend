# CardsAgainsHumanityDrfApi.InlineResponse2004

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**username** | **String** |  | 
**email** | **String** |  | 
