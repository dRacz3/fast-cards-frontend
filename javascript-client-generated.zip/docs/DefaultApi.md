# CardsAgainsHumanityDrfApi.DefaultApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**createLogin**](DefaultApi.md#createLogin) | **POST** /api/rest-auth/login/ | 
[**createLogout**](DefaultApi.md#createLogout) | **POST** /api/rest-auth/logout/ | 
[**createPasswordReset**](DefaultApi.md#createPasswordReset) | **POST** /api/rest-auth/password/reset/ | 
[**createPasswordResetConfirm**](DefaultApi.md#createPasswordResetConfirm) | **POST** /api/rest-auth/password/reset/confirm/ | 
[**createRegister**](DefaultApi.md#createRegister) | **POST** /api/rest-auth/registration/ | 
[**createVerifyEmail**](DefaultApi.md#createVerifyEmail) | **POST** /api/rest-auth/registration/verify-email/ | 
[**listBlackCards**](DefaultApi.md#listBlackCards) | **GET** /api/black_cards/ | 
[**listLogouts**](DefaultApi.md#listLogouts) | **GET** /api/rest-auth/logout/ | 
[**listSessionStates**](DefaultApi.md#listSessionStates) | **GET** /game_engine_api/session/{session_id}/view | 
[**listWhiteCards**](DefaultApi.md#listWhiteCards) | **GET** /api/white_cards/ | 
[**partialUpdateBlackCard**](DefaultApi.md#partialUpdateBlackCard) | **PATCH** /api/black_cards/{card_id}/ | 
[**partialUpdateWhiteCard**](DefaultApi.md#partialUpdateWhiteCard) | **PATCH** /api/white_cards/{card_id}/ | 
[**retrieveBlackCard**](DefaultApi.md#retrieveBlackCard) | **GET** /api/black_cards/{card_id}/ | 
[**retrieveWhiteCard**](DefaultApi.md#retrieveWhiteCard) | **GET** /api/white_cards/{card_id}/ | 
[**updateBlackCard**](DefaultApi.md#updateBlackCard) | **PUT** /api/black_cards/{card_id}/ | 
[**updateWhiteCard**](DefaultApi.md#updateWhiteCard) | **PUT** /api/white_cards/{card_id}/ | 

<a name="createLogin"></a>
# **createLogin**
> Body20 createLogin(opts)



Check the credentials and return the REST Token if the credentials are valid and authenticated. Calls Django Auth login method to register User ID in Django session framework  Accept the following POST parameters: username, password Return the REST Framework Token Object&#x27;s key.

### Example
```javascript
import CardsAgainsHumanityDrfApi from 'cards_agains_humanity_drf_api';

let apiInstance = new CardsAgainsHumanityDrfApi.DefaultApi();
let opts = { 
  'body': new CardsAgainsHumanityDrfApi.Body18() // Body18 | 
  'username2': "username_example" // String | 
  'email2': "email_example" // String | 
  'password2': "password_example" // String | 
  'username': "username_example" // String | 
  'email': "email_example" // String | 
  'password': "password_example" // String | 
};
apiInstance.createLogin(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Body18**](Body18.md)|  | [optional] 
 **username2** | **String**|  | [optional] 
 **email2** | **String**|  | [optional] 
 **password2** | **String**|  | [optional] 
 **username** | **String**|  | [optional] 
 **email** | **String**|  | [optional] 
 **password** | **String**|  | [optional] 

### Return type

[**Body20**](Body20.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/x-www-form-urlencoded, multipart/form-data
 - **Accept**: application/json

<a name="createLogout"></a>
# **createLogout**
> ModelObject createLogout()



Calls Django logout method and delete the Token object assigned to the current User object.  Accepts/Returns nothing.

### Example
```javascript
import CardsAgainsHumanityDrfApi from 'cards_agains_humanity_drf_api';

let apiInstance = new CardsAgainsHumanityDrfApi.DefaultApi();
apiInstance.createLogout((error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**ModelObject**](ModelObject.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="createPasswordReset"></a>
# **createPasswordReset**
> Body14 createPasswordReset(opts)



Calls Django Auth PasswordResetForm save method.  Accepts the following POST parameters: email Returns the success/fail message.

### Example
```javascript
import CardsAgainsHumanityDrfApi from 'cards_agains_humanity_drf_api';

let apiInstance = new CardsAgainsHumanityDrfApi.DefaultApi();
let opts = { 
  'body': new CardsAgainsHumanityDrfApi.Body12() // Body12 | 
  'email2': "email_example" // String | 
  'email': "email_example" // String | 
};
apiInstance.createPasswordReset(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Body12**](Body12.md)|  | [optional] 
 **email2** | **String**|  | [optional] 
 **email** | **String**|  | [optional] 

### Return type

[**Body14**](Body14.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/x-www-form-urlencoded, multipart/form-data
 - **Accept**: application/json

<a name="createPasswordResetConfirm"></a>
# **createPasswordResetConfirm**
> Body17 createPasswordResetConfirm(opts)



Password reset e-mail link is confirmed, therefore this resets the user&#x27;s password.  Accepts the following POST parameters: token, uid,     new_password1, new_password2 Returns the success/fail message.

### Example
```javascript
import CardsAgainsHumanityDrfApi from 'cards_agains_humanity_drf_api';

let apiInstance = new CardsAgainsHumanityDrfApi.DefaultApi();
let opts = { 
  'body': new CardsAgainsHumanityDrfApi.Body15() // Body15 | 
  'newPassword2': "newPassword1_example" // String | 
  'newPassword3': "newPassword2_example" // String | 
  'uid2': "uid_example" // String | 
  'token2': "token_example" // String | 
  'newPassword1': "newPassword1_example" // String | 
  'newPassword3': "newPassword2_example" // String | 
  'uid': "uid_example" // String | 
  'token': "token_example" // String | 
};
apiInstance.createPasswordResetConfirm(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Body15**](Body15.md)|  | [optional] 
 **newPassword2** | **String**|  | [optional] 
 **newPassword3** | **String**|  | [optional] 
 **uid2** | **String**|  | [optional] 
 **token2** | **String**|  | [optional] 
 **newPassword1** | **String**|  | [optional] 
 **newPassword3** | **String**|  | [optional] 
 **uid** | **String**|  | [optional] 
 **token** | **String**|  | [optional] 

### Return type

[**Body17**](Body17.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/x-www-form-urlencoded, multipart/form-data
 - **Accept**: application/json

<a name="createRegister"></a>
# **createRegister**
> InlineResponse2004 createRegister(opts)



### Example
```javascript
import CardsAgainsHumanityDrfApi from 'cards_agains_humanity_drf_api';

let apiInstance = new CardsAgainsHumanityDrfApi.DefaultApi();
let opts = { 
  'body': new CardsAgainsHumanityDrfApi.Body21() // Body21 | 
  'username2': "username_example" // String | 
  'email2': "email_example" // String | 
  'password2': "password1_example" // String | 
  'password3': "password2_example" // String | 
  'username': "username_example" // String | 
  'email': "email_example" // String | 
  'password1': "password1_example" // String | 
  'password3': "password2_example" // String | 
};
apiInstance.createRegister(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Body21**](Body21.md)|  | [optional] 
 **username2** | **String**|  | [optional] 
 **email2** | **String**|  | [optional] 
 **password2** | **String**|  | [optional] 
 **password3** | **String**|  | [optional] 
 **username** | **String**|  | [optional] 
 **email** | **String**|  | [optional] 
 **password1** | **String**|  | [optional] 
 **password3** | **String**|  | [optional] 

### Return type

[**InlineResponse2004**](InlineResponse2004.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/x-www-form-urlencoded, multipart/form-data
 - **Accept**: application/json

<a name="createVerifyEmail"></a>
# **createVerifyEmail**
> Body26 createVerifyEmail(opts)



### Example
```javascript
import CardsAgainsHumanityDrfApi from 'cards_agains_humanity_drf_api';

let apiInstance = new CardsAgainsHumanityDrfApi.DefaultApi();
let opts = { 
  'body': new CardsAgainsHumanityDrfApi.Body24() // Body24 | 
  'key2': "key_example" // String | 
  'key': "key_example" // String | 
};
apiInstance.createVerifyEmail(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Body24**](Body24.md)|  | [optional] 
 **key2** | **String**|  | [optional] 
 **key** | **String**|  | [optional] 

### Return type

[**Body26**](Body26.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/x-www-form-urlencoded, multipart/form-data
 - **Accept**: application/json

<a name="listBlackCards"></a>
# **listBlackCards**
> InlineResponse2002 listBlackCards(opts)



### Example
```javascript
import CardsAgainsHumanityDrfApi from 'cards_agains_humanity_drf_api';

let apiInstance = new CardsAgainsHumanityDrfApi.DefaultApi();
let opts = { 
  'page': 56, // Number | A page number within the paginated result set.
  'search': "search_example" // String | A search term.
};
apiInstance.listBlackCards(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **Number**| A page number within the paginated result set. | [optional] 
 **search** | **String**| A search term. | [optional] 

### Return type

[**InlineResponse2002**](InlineResponse2002.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="listLogouts"></a>
# **listLogouts**
> [ModelObject] listLogouts()



Calls Django logout method and delete the Token object assigned to the current User object.  Accepts/Returns nothing.

### Example
```javascript
import CardsAgainsHumanityDrfApi from 'cards_agains_humanity_drf_api';

let apiInstance = new CardsAgainsHumanityDrfApi.DefaultApi();
apiInstance.listLogouts((error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**[ModelObject]**](ModelObject.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="listSessionStates"></a>
# **listSessionStates**
> [ModelObject] listSessionStates(sessionId)



### Example
```javascript
import CardsAgainsHumanityDrfApi from 'cards_agains_humanity_drf_api';

let apiInstance = new CardsAgainsHumanityDrfApi.DefaultApi();
let sessionId = "sessionId_example"; // String | 

apiInstance.listSessionStates(sessionId, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sessionId** | **String**|  | 

### Return type

[**[ModelObject]**](ModelObject.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="listWhiteCards"></a>
# **listWhiteCards**
> InlineResponse200 listWhiteCards(opts)



### Example
```javascript
import CardsAgainsHumanityDrfApi from 'cards_agains_humanity_drf_api';

let apiInstance = new CardsAgainsHumanityDrfApi.DefaultApi();
let opts = { 
  'page': 56, // Number | A page number within the paginated result set.
  'search': "search_example" // String | A search term.
};
apiInstance.listWhiteCards(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **Number**| A page number within the paginated result set. | [optional] 
 **search** | **String**| A search term. | [optional] 

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="partialUpdateBlackCard"></a>
# **partialUpdateBlackCard**
> Body8 partialUpdateBlackCard(cardId, opts)



### Example
```javascript
import CardsAgainsHumanityDrfApi from 'cards_agains_humanity_drf_api';

let apiInstance = new CardsAgainsHumanityDrfApi.DefaultApi();
let cardId = "cardId_example"; // String | A unique integer value identifying this black card.
let opts = { 
  'body': new CardsAgainsHumanityDrfApi.Body9() // Body9 | 
  'text2': "text_example" // String | 
  'icon2': "icon_example" // String | 
  'deck2': "deck_example" // String | 
  'pick2': 56 // Number | 
  'text': "text_example" // String | 
  'icon': "icon_example" // String | 
  'deck': "deck_example" // String | 
  'pick': 56 // Number | 
  'search': "search_example" // String | A search term.
};
apiInstance.partialUpdateBlackCard(cardId, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cardId** | **String**| A unique integer value identifying this black card. | 
 **body** | [**Body9**](Body9.md)|  | [optional] 
 **text2** | **String**|  | [optional] 
 **icon2** | **String**|  | [optional] 
 **deck2** | **String**|  | [optional] 
 **pick2** | **Number**|  | [optional] 
 **text** | **String**|  | [optional] 
 **icon** | **String**|  | [optional] 
 **deck** | **String**|  | [optional] 
 **pick** | **Number**|  | [optional] 
 **search** | **String**| A search term. | [optional] 

### Return type

[**Body8**](Body8.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/x-www-form-urlencoded, multipart/form-data
 - **Accept**: application/json

<a name="partialUpdateWhiteCard"></a>
# **partialUpdateWhiteCard**
> Body2 partialUpdateWhiteCard(cardId, opts)



### Example
```javascript
import CardsAgainsHumanityDrfApi from 'cards_agains_humanity_drf_api';

let apiInstance = new CardsAgainsHumanityDrfApi.DefaultApi();
let cardId = "cardId_example"; // String | A unique integer value identifying this white card.
let opts = { 
  'body': new CardsAgainsHumanityDrfApi.Body3() // Body3 | 
  'text2': "text_example" // String | 
  'icon2': "icon_example" // String | 
  'deck2': "deck_example" // String | 
  'text': "text_example" // String | 
  'icon': "icon_example" // String | 
  'deck': "deck_example" // String | 
  'search': "search_example" // String | A search term.
};
apiInstance.partialUpdateWhiteCard(cardId, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cardId** | **String**| A unique integer value identifying this white card. | 
 **body** | [**Body3**](Body3.md)|  | [optional] 
 **text2** | **String**|  | [optional] 
 **icon2** | **String**|  | [optional] 
 **deck2** | **String**|  | [optional] 
 **text** | **String**|  | [optional] 
 **icon** | **String**|  | [optional] 
 **deck** | **String**|  | [optional] 
 **search** | **String**| A search term. | [optional] 

### Return type

[**Body2**](Body2.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/x-www-form-urlencoded, multipart/form-data
 - **Accept**: application/json

<a name="retrieveBlackCard"></a>
# **retrieveBlackCard**
> InlineResponse2003 retrieveBlackCard(cardId, opts)



### Example
```javascript
import CardsAgainsHumanityDrfApi from 'cards_agains_humanity_drf_api';

let apiInstance = new CardsAgainsHumanityDrfApi.DefaultApi();
let cardId = "cardId_example"; // String | A unique integer value identifying this black card.
let opts = { 
  'search': "search_example" // String | A search term.
};
apiInstance.retrieveBlackCard(cardId, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cardId** | **String**| A unique integer value identifying this black card. | 
 **search** | **String**| A search term. | [optional] 

### Return type

[**InlineResponse2003**](InlineResponse2003.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="retrieveWhiteCard"></a>
# **retrieveWhiteCard**
> InlineResponse2001 retrieveWhiteCard(cardId, opts)



### Example
```javascript
import CardsAgainsHumanityDrfApi from 'cards_agains_humanity_drf_api';

let apiInstance = new CardsAgainsHumanityDrfApi.DefaultApi();
let cardId = "cardId_example"; // String | A unique integer value identifying this white card.
let opts = { 
  'search': "search_example" // String | A search term.
};
apiInstance.retrieveWhiteCard(cardId, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cardId** | **String**| A unique integer value identifying this white card. | 
 **search** | **String**| A search term. | [optional] 

### Return type

[**InlineResponse2001**](InlineResponse2001.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="updateBlackCard"></a>
# **updateBlackCard**
> Body8 updateBlackCard(cardId, opts)



### Example
```javascript
import CardsAgainsHumanityDrfApi from 'cards_agains_humanity_drf_api';

let apiInstance = new CardsAgainsHumanityDrfApi.DefaultApi();
let cardId = "cardId_example"; // String | A unique integer value identifying this black card.
let opts = { 
  'body': new CardsAgainsHumanityDrfApi.Body6() // Body6 | 
  'text2': "text_example" // String | 
  'icon2': "icon_example" // String | 
  'deck2': "deck_example" // String | 
  'pick2': 56 // Number | 
  'text': "text_example" // String | 
  'icon': "icon_example" // String | 
  'deck': "deck_example" // String | 
  'pick': 56 // Number | 
  'search': "search_example" // String | A search term.
};
apiInstance.updateBlackCard(cardId, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cardId** | **String**| A unique integer value identifying this black card. | 
 **body** | [**Body6**](Body6.md)|  | [optional] 
 **text2** | **String**|  | [optional] 
 **icon2** | **String**|  | [optional] 
 **deck2** | **String**|  | [optional] 
 **pick2** | **Number**|  | [optional] 
 **text** | **String**|  | [optional] 
 **icon** | **String**|  | [optional] 
 **deck** | **String**|  | [optional] 
 **pick** | **Number**|  | [optional] 
 **search** | **String**| A search term. | [optional] 

### Return type

[**Body8**](Body8.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/x-www-form-urlencoded, multipart/form-data
 - **Accept**: application/json

<a name="updateWhiteCard"></a>
# **updateWhiteCard**
> Body2 updateWhiteCard(cardId, opts)



### Example
```javascript
import CardsAgainsHumanityDrfApi from 'cards_agains_humanity_drf_api';

let apiInstance = new CardsAgainsHumanityDrfApi.DefaultApi();
let cardId = "cardId_example"; // String | A unique integer value identifying this white card.
let opts = { 
  'body': new CardsAgainsHumanityDrfApi.Body() // Body | 
  'text2': "text_example" // String | 
  'icon2': "icon_example" // String | 
  'deck2': "deck_example" // String | 
  'text': "text_example" // String | 
  'icon': "icon_example" // String | 
  'deck': "deck_example" // String | 
  'search': "search_example" // String | A search term.
};
apiInstance.updateWhiteCard(cardId, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cardId** | **String**| A unique integer value identifying this white card. | 
 **body** | [**Body**](Body.md)|  | [optional] 
 **text2** | **String**|  | [optional] 
 **icon2** | **String**|  | [optional] 
 **deck2** | **String**|  | [optional] 
 **text** | **String**|  | [optional] 
 **icon** | **String**|  | [optional] 
 **deck** | **String**|  | [optional] 
 **search** | **String**| A search term. | [optional] 

### Return type

[**Body2**](Body2.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/x-www-form-urlencoded, multipart/form-data
 - **Accept**: application/json

